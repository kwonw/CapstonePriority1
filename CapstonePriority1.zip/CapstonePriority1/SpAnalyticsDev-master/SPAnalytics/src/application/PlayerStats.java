package application;

public class PlayerStats {
public String season;
public int GP;
public Position position;
public PlayerStats() {}
public PlayerStats(String season, int gP, Position position) {
	super();
	this.season = season;
	GP = gP;
	this.position = position;
}


}
